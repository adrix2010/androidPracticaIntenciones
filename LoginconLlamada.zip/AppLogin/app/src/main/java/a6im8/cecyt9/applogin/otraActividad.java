package a6im8.cecyt9.applogin;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.appcompat.R;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Usuario on 16/03/2017.
 */

public class otraActividad extends AppCompatActivity {
    TextView lblNombre, lblContra;
    String nombreUsr, contra;
    Button btnMarcar,btnEnviar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otraactividad);
        lblNombre = (TextView) findViewById(R.id.vistaDatos);
        lblContra = (TextView) findViewById(R.id.vistaDatos2);
        btnMarcar = (Button) findViewById(R.id.Marcar);
        btnEnviar = (Button) findViewById(R.id.Enviar);
        Intent intento2 = getIntent();

        String nombreUsr = intento2.getExtras().getString("Nombre").toString();
        String contra = intento2.getExtras().getString("Contra").toString();

        lblNombre.setText(lblNombre.getText().toString()+nombreUsr);
        lblContra.setText(lblContra.getText().toString()+contra);
    }
    public void llamadaTelefono(View llamada)
    {
        Intent intent = new Intent(Intent.ACTION_CALL,
                Uri.parse("tel:5578956745"));
        startActivity(intent);
    }

    public void mandarCorreo(View correo)
    {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Asunto: Prueba");
        intent.putExtra(Intent.EXTRA_TEXT, "Contenido del correo: Reserva confirmada");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "adrix201065moli@gmail.com"} );
        startActivity(intent);
    }
}
